import math

def areaTriangulo(base,altura):
    return base*altura/2

def areaCirculo(radio):
    return (radio**2)*math.pi

print(areaTriangulo(4,5))
print(areaCirculo(3))